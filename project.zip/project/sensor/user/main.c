#include "sysinc.h"
#include "car_ctrl.h"
#include "hc_sr04.h"

#define KEY_CTRL PAin(8)

#define DISTANCE_FOLLOW 1500
#define DISTANCE_DIF  500
int map[]={0, 0, 2, 2, 0, 2, 1, 2, 1, 0, 1, 2, 0, 1, 0, 31, 0, 0, 32, 2, 1, 1, 2, 0, 0, 2, 2, 32, 0, 0, 0, 2, 1, 0, 2, 0, 0, 31, 1, 2, 0, 2, 0, 2, 0, 0, 1, 0, 32, 2, 2, 31, 2, 1, 2, 0, 0, 2, 2, 32, 0, 0, 0, 2, 1, 0, 2, 0, 0, 31, 2, 2, 2, 0, 2, 0, 0, 2, 2};
int LeftSensorValue1 = 0;
int LeftSensorValue2 = 0;
int RightSensorValue1 = 0;
int RightSensorValue2 = 0;
int cnt=0;
u8 flag_run = 0;
u16 test;
int find_cross_road(){ //???????? 1?????? 0????
	int t=0;
	if(LeftSensorValue2 ==0 && RightSensorValue2 ==0){t=0;}
	else if(LeftSensorValue2 == 0 && RightSensorValue2 ==1){t=1;}
	else if(RightSensorValue2 == 0 && LeftSensorValue2 ==1){t=1;}
	else if(LeftSensorValue2 ==1 && RightSensorValue2 == 1){t=1;}
	if (t == 1){
		return 1;
	}
	else return 0;
}
void led_init(){
	LeftSensorValue1  = PCin(14);
	RightSensorValue1 = PCin(15);
	LeftSensorValue2  = PCin(13);
	RightSensorValue2 = PBin(10);
}
void timer2(){
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET){  //??TIM3????????
		PAout(7) = !PAout(7);
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);  //??TIMx?????? 
	}
}

void key_int(){
		SYSTICK_DelayMs(5);
		if(KEY_CTRL == 0){
			flag_run = !flag_run;
			while(KEY_CTRL == 0);
		}
}
void xunji(){ //??  
        if(LeftSensorValue1 ==  1&& RightSensorValue1 == 0){car_turn_left();SYSTICK_DelayMs(5);}
        else if(LeftSensorValue1 == 0 && RightSensorValue1 == 1){car_turn_right();SYSTICK_DelayMs(5);}             
		    else {car_forward();SYSTICK_DelayMs(1); }	
}
void speedy_xunji(){
	 if(LeftSensorValue1 ==  1&& RightSensorValue1 == 0){car_turn_left();SYSTICK_DelayMs(5);}
   else if(LeftSensorValue1 == 0 && RightSensorValue1 == 1){car_turn_right();SYSTICK_DelayMs(5);}             
	 else {car_forward_fast();SYSTICK_DelayMs(1); }	
}
void slow_xunji(){
	 if(LeftSensorValue1 ==  1&& RightSensorValue1 == 0){car_turn_left_place_slow();SYSTICK_DelayMs(4);}
   else if(LeftSensorValue1 == 0 && RightSensorValue1 == 1){car_turn_right_place_slow();SYSTICK_DelayMs(4);}             
	 //else {car_forward_veryslow();SYSTICK_DelayMs(1);}	
}
void fast_forward(){
	for(int i=0;i<=5;i++){led_init();speedy_xunji();}
	while(1){
		led_init();
		if (find_cross_road() == 1){cnt++;car_forward_fast();SYSTICK_DelayMs(300);break;}
		speedy_xunji();
	}
	for(int i=0;i<=5;i++){led_init();speedy_xunji();}
}
void cross_turn(int cnt){ //???????? cnt????map?????????????
	car_forward_slow();SYSTICK_DelayMs(320);
	if(map[cnt]==0){car_turn_left_place();SYSTICK_DelayMs(950);}
	else if(map[cnt]==1){car_forward();SYSTICK_DelayMs(500); }			
	else if (map[cnt]==2){car_turn_right_place();SYSTICK_DelayMs(950);}
	else if(map[cnt]==3){car_turn_right_place();SYSTICK_DelayMs(2000);}
  //car_forward();SYSTICK_DelayMs(10);
	//��ת��
	/*for(int i=0;i<=20;i++){
	if(LeftSensorValue2 == 0 && RightSensorValue2 ==1){car_turn_left();SYSTICK_DelayMs(10);}
	else if(RightSensorValue2 == 0 && LeftSensorValue2 ==1){car_turn_right();SYSTICK_DelayMs(10);}
	}*/
	for(int i=0;i<=20;i++){led_init();xunji();}
}

void check_treasure2(){
	int flag=0;
		for(int i=0;i<=5;i++){
			for(int i=0;i<=10;i++){led_init();slow_xunji();};
			car_forward_veryslow();SYSTICK_DelayMs(2000);
		}			
	 for(int i=0;i<=20;i++){
		if(USART_RX_STA&0x8000){
			flag=1;
			car_forward_veryslow();SYSTICK_DelayMs(4000);
			cnt++;
			car_turn_right_place_slow();SYSTICK_DelayMs(2200);
			USART_RX_STA=0;
			//car_brake();SYSTICK_DelayMs(10000000);
			break;
		}
	}
	 if(flag==0){cnt++;car_turn_right_place_slow();SYSTICK_DelayMs(2200);};
}
void check_treasure1(){
	int flag=0;
	for(int i=0;i<=10;i++){led_init();slow_xunji();};
	car_forward_veryslow();SYSTICK_DelayMs(4000); 
	for(int i=0;i<=20;i++){
		if(USART_RX_STA&0x8000){
			flag=1;
			car_forward_veryslow();SYSTICK_DelayMs(2200);
			cnt++;
			car_turn_right_place_slow();SYSTICK_DelayMs(2200);
			USART_RX_STA=0;
			//car_brake();SYSTICK_DelayMs(10000000);
			break;
		}
	}
	if(flag==0){cnt++;car_turn_right_place_slow();SYSTICK_DelayMs(2200);};
}
int main(void){
	//???????
	NVIC_init();
	SYSTICK_DelayInit();	    	 //???????	  	
	//??????
	TIM_ms_Init(TIM2, 500, TIM_IT_Update,2, ENABLE);	//??????2,??500ms
 	TIMER_CallbackInstall(HW_TIMER2, timer2);	 
	GPIO_QuickInit(HW_GPIOA, GPIO_Pin_7, GPIO_Mode_Out_PP);//???????????
	//??????? 	 
	GPIO_QuickInit(HW_GPIOA, GPIO_Pin_8, GPIO_Mode_IPU);//???????????
	EXTI_QuickInit(HW_EXTIA, EXTI_Pin_8, 3, 3);
	EXTI_CallbackInstall(EXTI_Pin_8, key_int);
  hc_sr04_init();
	GPIO_QuickInit(HW_GPIOC, GPIO_Pin_13, GPIO_Mode_IPU);//???????????
	GPIO_QuickInit(HW_GPIOC, GPIO_Pin_14, GPIO_Mode_IPU);//???????????
	GPIO_QuickInit(HW_GPIOC, GPIO_Pin_15, GPIO_Mode_IPU);//???????????
	GPIO_QuickInit(HW_GPIOB, GPIO_Pin_10, GPIO_Mode_IPU);//???????????
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
  GPIO_SetBits(GPIOA, GPIO_Pin_3);
	car_init();
	UART_QuickInit(HW_UART1, 115200, 2, 2, ENABLE);
	//car_set_motor_speed(6000, 6000);
	int open_xunji=1;
	car_forward();SYSTICK_DelayMs(500);
	while(1){
		if(map[cnt]==31){check_treasure1();continue;};
		if(map[cnt]==32){check_treasure2();continue;};
		open_xunji=1;
		led_init();
		if(map[cnt]==1){fast_forward();continue;};
		if(find_cross_road() == 1){open_xunji=0;cross_turn(cnt);cnt++;continue;};
	//SYSTICK_DelayMs(1000);
		if(open_xunji==1){led_init();xunji();};
	}
	/*-------------------------------------------------------------------------------------------------------------------*/
}

