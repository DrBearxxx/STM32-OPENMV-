#include "car_ctrl.h"

void car_init(){
	
	
	
	TIM_PWM_Init(MOTOR_TIMERX, MOTOR_L_PWM, 100 ,ENABLE);
	TIM_PWM_Init(MOTOR_TIMERX, MOTOR_R_PWM, 100 ,ENABLE);
	
	GPIO_QuickInit(HW_GPIOB, GPIO_Pin_4, GPIO_Mode_Out_PP); 
	GPIO_QuickInit(HW_GPIOB, GPIO_Pin_5, GPIO_Mode_Out_PP); 
	GPIO_QuickInit(HW_GPIOB, GPIO_Pin_8, GPIO_Mode_Out_PP);//��ʼ����LED���ӵ�Ӳ���ӿ�
	GPIO_QuickInit(HW_GPIOB, GPIO_Pin_9, GPIO_Mode_Out_PP);//��ʼ����LED���ӵ�Ӳ���ӿ�
	
	TIM_SetCompare(MOTOR_TIMERX, MOTOR_L_PWM, 5000);
	TIM_SetCompare(MOTOR_TIMERX, MOTOR_R_PWM, 5000);

	MOTOR_R_F = 0;
	MOTOR_R_B = 0;

	MOTOR_L_F = 0;
	MOTOR_L_B = 0;
}

void car_forward(){
	MOTOR_R_F = 1;
	MOTOR_R_B = 0;

	MOTOR_L_F = 0;
	MOTOR_L_B = 1;
  	car_set_motor_speed(5000, 5000);
}
void car_forward_fast(){
	MOTOR_R_F = 1;
	MOTOR_R_B = 0;

	MOTOR_L_F = 0;
	MOTOR_L_B = 1;
  	car_set_motor_speed(5000, 5000);
}
void car_forward_slow(){
	MOTOR_R_F = 1;
	MOTOR_R_B = 0;

	MOTOR_L_F = 0;
	MOTOR_L_B = 1;
  	car_set_motor_speed(3500, 3500);
}
void car_forward_veryslow(){
	MOTOR_R_F = 1;
	MOTOR_R_B = 0;

	MOTOR_L_F = 0;
	MOTOR_L_B = 1;
  	car_set_motor_speed(1000, 1000);
}
void car_back(void){
	MOTOR_R_F = 1;
	MOTOR_R_B = 0;

	MOTOR_L_F = 0;
	MOTOR_L_B = 1;
}

void car_brake(){
	MOTOR_R_F = 0;
	MOTOR_R_B = 0;

	MOTOR_L_F = 0;
	MOTOR_L_B = 0;
}

void car_turn_left_place(void){
	MOTOR_R_F = 1;
	MOTOR_R_B = 0;

	MOTOR_L_F = 1;
	MOTOR_L_B = 0;
  car_set_motor_speed(3000,3000);
}

void car_turn_right_place(void){
	MOTOR_R_F = 0;
	MOTOR_R_B = 1;

	MOTOR_L_F = 0;
	MOTOR_L_B = 1;
 car_set_motor_speed(3000,3000);
}
void car_turn_left_place_slow(void){
	MOTOR_R_F = 1;
	MOTOR_R_B = 0;

	MOTOR_L_F = 1;
	MOTOR_L_B = 0;
  car_set_motor_speed(3000,3000);
}
void car_turn_right_place_slow(void){
	MOTOR_R_F = 0;
	MOTOR_R_B = 1;

	MOTOR_L_F = 0;
	MOTOR_L_B = 1;
 car_set_motor_speed(3000,3000);
}
void car_turn_left(void){
  MOTOR_R_F = 1;
	MOTOR_R_B = 0;

	MOTOR_L_F = 1;
	MOTOR_L_B = 0;
  car_set_motor_speed(3000,3000);
  //SYSTICK_DelayMs(10);
}

void car_turn_right(void){
	MOTOR_R_F = 0;
	MOTOR_R_B = 1;

	MOTOR_L_F = 0;
	MOTOR_L_B = 1;
  car_set_motor_speed(3000,3000); 
  //SYSTICK_DelayMs(10);
}
void car_set_motor_speed(u16 motor_A_speed, u16 motor_B_speed){
	TIM_SetCompare(MOTOR_TIMERX, MOTOR_L_PWM, motor_A_speed);
	TIM_SetCompare(MOTOR_TIMERX, MOTOR_R_PWM, motor_B_speed);
}

void car_dif_run(u16 motor_A_speed, u16 motor_B_speed){
	car_set_motor_speed( motor_A_speed, motor_B_speed);
	car_forward();
}

