#ifndef _CAR_CTRL_H_
#define _CAR_CTRL_H_

#include "sysinc.h"

#define MOTOR_TIMERX TIM4
	

#define MOTOR_L_PWM PWM_CH2
#define MOTOR_L_F PBout(8)
#define MOTOR_L_B PBout(9)

#define MOTOR_R_PWM PWM_CH1
#define MOTOR_R_F PBout(5)
#define MOTOR_R_B PBout(4)

void car_init(void);
void car_forward(void);
void car_forward_fast(void);
void car_forward_slow(void);
void car_forward_veryslow(void);
void car_back(void);
void car_brake(void);

void car_turn_left_place(void);
void car_turn_right_place(void);
void car_turn_right_place_slow(void);
void car_turn_left_place_slow(void);
void car_turn_left(void);
void car_turn_right(void);

void car_set_motor_speed(u16 motor_A_speed, u16 motor_B_speed);
void car_dif_run(u16 motor_A_speed, u16 motor_B_speed);
#endif

